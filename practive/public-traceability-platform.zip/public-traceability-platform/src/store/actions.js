/**
 * vuex中的actions
 */
//import APIservice from '../service/stock.service'

export default {

}